package src.DatConRecs.Created4V3;

import src.DatConRecs.Payload;
import src.Files.ConvertDat;

public class RecMagRaw6_20350 extends MagRawGroup {
    public RecMagRaw6_20350(ConvertDat convertDat) {
        super(convertDat, 20350, 6, 0);
    }

    public void process(Payload _payload) {
        super.process(_payload);
    }
}
