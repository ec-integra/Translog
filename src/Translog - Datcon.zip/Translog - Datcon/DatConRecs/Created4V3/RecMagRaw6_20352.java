package src.DatConRecs.Created4V3;

import src.DatConRecs.Payload;
import src.Files.ConvertDat;

public class RecMagRaw6_20352 extends MagRawGroup {
    public RecMagRaw6_20352(ConvertDat convertDat) {
        super(convertDat, 20352, 6, 2);
    }

    public void process(Payload _payload) {
        super.process(_payload);
    }
}
