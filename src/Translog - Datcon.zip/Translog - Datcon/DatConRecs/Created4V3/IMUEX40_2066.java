package src.DatConRecs.Created4V3;

import src.DatConRecs.Payload;
import src.Files.ConvertDat;

public class IMUEX40_2066 extends IMUEX40 {

    public IMUEX40_2066(ConvertDat convertDat) {
        super(convertDat, 2066, 40, 2);
    }

    @Override
    public void process(Payload _payload) {
        super.process(_payload);
    }

}
