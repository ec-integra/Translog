package src.DatConRecs.Created4V3;

import src.DatConRecs.Payload;
import src.Files.ConvertDat;

public class IMUEX40_2065 extends IMUEX40 {

    public IMUEX40_2065(ConvertDat convertDat) {
        super(convertDat, 2065, 40, 1);
    }

    @Override
    public void process(Payload _payload) {
        super.process(_payload);
    }

}
