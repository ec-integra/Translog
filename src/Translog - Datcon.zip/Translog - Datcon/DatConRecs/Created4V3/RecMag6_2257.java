package src.DatConRecs.Created4V3;

import src.DatConRecs.Payload;
import src.Files.ConvertDat;

public class RecMag6_2257 extends MagGroup {

    public RecMag6_2257(ConvertDat convertDat) {
        super(convertDat, 2257, 6, 1);
    }

    public void process(Payload _payload) {
        super.process(_payload);
    }
}
