package src.GUI;

import java.awt.Dimension;

import javax.swing.JFrame;

public class DatConFrame extends JFrame {
    
    @Override
    public void setSize(Dimension d) {
        super.setSize(d);
    }

}
