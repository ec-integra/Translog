package src.DatConRecs.Created4V3;

import src.DatConRecs.*;
import src.Files.ConvertDat;
import src.Files.ConvertDat.lineType;
import src.Files.DatConLog;
import src.Files.Signal;
import src.Files.Units;

public class BatBox32_5003 extends BatBox32_500X {
    

    public BatBox32_5003(ConvertDat convertDat) {
        super(convertDat, 5003, 0);
    }

   

}
